//
//  ViewController.swift
//  Test1Starter
//
//  Created by zebra on 2021-03-26.
//  Copyright © 2021 zebra. All rights reserved.
//

import UIKit

class Screen1ViewController: UIViewController {
    
    // ---------------
    // MARK: Outlets
    // ---------------
    @IBOutlet weak var lblGrass: UILabel!
    @IBOutlet weak var lblWater: UILabel!
    @IBOutlet weak var lblElectric: UILabel!

    // ---------------
    // MARK: ViewDidLoad
    // ---------------
    override func viewDidLoad() {
           super.viewDidLoad()
               
    }
    
    // ---------------
    // MARK: Actions
    // ---------------
    @IBAction func electricButtonPressed(_ sender: Any) {
        startBattle(with:PokemonType.ELECTRIC)
    }
    
    @IBAction func grassButtonPressed(_ sender: Any) {
        startBattle(with:PokemonType.GRASS)
    }
    
    @IBAction func waterButtonPressed(_ sender: Any) {
        startBattle(with:PokemonType.WATER)
    }
    
    @IBAction func rerollPressed(_ sender: Any) {
        print("You pressed the reroll button!")
        // TODO: Fill in this logic
    }

    // ---------------
    // MARK: Functions
    // ---------------
    func startBattle(with pokemonType:PokemonType) {
        print("You picked a \(pokemonType) pokemon!")
        // TODO: Fill in this logic
    }
    func rollValues() {
        // TODO: Fill in this logic
    }
}

