//
//  Test.swift
//  Test1Starter
//
//  Created by zebra on 2021-03-26.
//  Copyright © 2021 zebra. All rights reserved.
//

import Foundation

enum PokemonType:String {
    case GRASS = "Grass"
    case WATER = "Water"
    case ELECTRIC = "Electric"
}
