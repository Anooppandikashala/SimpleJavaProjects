//
//  SecondScreenViewController.swift
//  Test1Starter
//
//  Created by user189924 on 3/27/21.
//  Copyright © 2021 zebra. All rights reserved.
//

import UIKit

class SecondScreenViewController: UIViewController {
    
    @IBOutlet weak var playerDetails: UILabel!
    
    @IBOutlet weak var computerDetails: UILabel!
    
    @IBOutlet weak var result: UILabel!
    
    var pokeType:PokemonType=PokemonType.ELECTRIC;
    var exp:Int=0;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("poketype :\(pokeType)")
        
        let g = 150;
        let e = 120;
        let w = 100;
        
        
        var computerExp = Int.random(in: 100...150);
        
        if(computerExp > 100 && computerExp < 120)
        {
            computerExp = 100;
            computerDetails.text = "WATER"
        }
        else if (computerExp > 120 && computerExp < 140)
        {
            computerExp = 120 + 12;
            computerDetails.text = "ELECTRIC"
        }
        else{
            computerExp = 150;
            computerDetails.text = "GRASS"        }
        
        
        playerDetails.text = "\(pokeType)"
        
        if(pokeType == PokemonType.ELECTRIC)
        {
            exp = exp + (exp * 20);
        }
        
        
        
        if(computerExp > exp)
        {
            result.text = "Computer Win"
        }
        else{
            result.text = "User Win";
        }
        
        
        

        // Do any additional setup after loading the view.
    }
    
    @IBAction func onBackPressed(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
